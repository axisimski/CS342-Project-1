/* This file contains the user interface code for the Infix Evaluation Project
 *  Project 5 for CS 211 for Fall 2017
 *
 * Date: 10/21/17
 *
 * Author: Pat Troy
 *
 */

#include "proj5Tokens.h"
#include <stdio.h>
#include <stdlib.h>

void printCommands();

void processExpression (Token inputToken, TokenReader *tr, int deBug);

int main(int argc, char *argv[])
{
    /***************************************************************/
    /* Add code for checking command line arguments for debug mode */

	//Set a debug mode varriable
	int deBug=0;
	int i;
	 for(i = 0; i < argc; i++){
		if(strcmp(argv[i], "-d") == 0){
			printf("\nDebug mode is on\n");
			deBug = 1;
		}
	}


    Token inputToken;
    TokenReader tr;

    printf ("Starting Expression Evaluation Program\n\n");
    printf ("Enter Expression: ");


    inputToken = tr.getNextToken ();

    while (inputToken.equalsType(QUIT) == false)
    {
      /* check first Token on Line of input */
      if(inputToken.equalsType(HELP))
      {
       printCommands();
       tr.clearToEoln();
      }
      else if(inputToken.equalsType(ERROR))
      {
       printf ("Invalid Input - For a list of valid commands, type ?\n");
       tr.clearToEoln();
      }
      else if(inputToken.equalsType(EOLN))
      {
       printf ("Blank Line - Do Nothing\n");
       /* blank line - do nothing */
      }
      else
      {
       processExpression(inputToken, &tr, deBug);
      }

      printf ("\nEnter Expression: ");
      inputToken = tr.getNextToken ();
    }

  printf ("Quitting Program\n");
  return 1;
}

void printCommands()
{
 printf ("The commands for this program are:\n\n");
 printf ("q - to quit the program\n");
 printf ("? - to list the accepted commands\n");
 printf ("or any infix mathematical expression using operators of (), *, /, +, -\n");
}

void processExpression (Token inputToken, TokenReader *tr, int deBug)
{
 /**********************************************/
 /* Declare both stack head pointers here      */
 
 MyStack *vals=new MyStack; //Stack pointer to hold values
 MyStack *syms=new MyStack; //Stack pointer to hold symbols (operators), idk why I called it syms, but it stuck.
 	
  
 /* Loop until the expression reaches its End */
 while (inputToken.equalsType(EOLN) == false)
   {
    /* The expression contain a VALUE */
    if (inputToken.equalsType(VALUE))
      {
       /* make this a debugMode statement */
       if(deBug==1){
	        printf ("Val: %d, ", inputToken.getValue() );      	
	   }
		
		//push onto values stack
		vals->push(inputToken.getValue());
       // add code to perform this operation here

      }


    /* The expression contains an OPERATOR */
    else if (inputToken.equalsType(OPERATOR))
      {
       /* make this a debugMode statement */
       
       if(deBug==1){
          printf ("OP: %c, ", inputToken.getOperator() );       	
	   }
       	
		//If open parenthasie push onto operator stack        
       if(inputToken.getOperator()=='('){
       	  syms->push(inputToken.getOperator());
	   }
	 //-------------------------------------------------------------------------------------------------------------------------	
		
		//Follow provided algoirthm
		if(inputToken.getOperator()=='+'||inputToken.getOperator()=='-'){
		 			
			while(syms->isEmpty()!=1&&(syms->stop()=='*'||syms->stop()=='/'||syms->stop()=='+'||syms->stop()=='-')){
				
			if(syms->stop() != '+' && syms->stop() != '-' && syms->stop() != '*' && syms->stop() != '/'){
              printf("ERROR Operator stack contains unrecognized symbol");
              return;
            }
       		     
				//The following is PopAndEval()	  		
      			int val2=vals->pop();
				int val1=vals->pop();
				int val3;
 				char op=syms->pop(); 
 
 	 		    if(op== '+'){val3 = val1+val2;}
     	    	if(op== '-'){val3 = val1-val2;}  
      	    	if(op== '*'){val3 = val1*val2;}    
           		if(op== '/'){val3 = val1/val2;}    
	       		
				vals->push(val3); //push new value onto values stack

		  	}
			//push onto stack operator	
       	  syms->push(inputToken.getOperator());
		}
	//-------------------------------------------------------------------------------------------------------------------------	
		if(inputToken.getOperator()=='*'||inputToken.getOperator()=='/'){
			
			while(syms->isEmpty()!=1&&(syms->stop()=='*'||syms->stop()=='/')){
				
			if(syms->stop() != '+' && syms->stop() != '-' && syms->stop() != '*' && syms->stop() != '/'){
              printf("ERROR Operator stack contains unrecognized symbol");
              return;
            }       
	   			//The following is PopAndEval()	  		
  		
      			int val2=vals->pop();
				int val1=vals->pop();
				int val3;
 				char op=syms->pop();
 
 	 		    if(op== '+'){val3 = val1+val2;}
     	    	if(op== '-'){val3 = val1-val2;}  
      	    	if(op== '*'){val3 = val1*val2;}    
           		if(op== '/'){val3 = val1/val2;}    
	       		
				vals->push(val3); //push value onto values stack

		  	}	
		  		//push onto stack operator	
		  syms->push(inputToken.getOperator());

		}
	//-------------------------------------------------------------------------------------------------------------------------	
		//If operator is closed parenthasies...follow algorithm on project handout
		if(inputToken.getOperator()==')'){
			
			while(syms->isEmpty()!=1&&(syms->stop()!='(')){
				
			if(syms->stop() != '+' && syms->stop() != '-' && syms->stop() != '*' && syms->stop() != '/'){
              printf("ERROR Operator stack contains unrecognized symbol");
              return;
            }
       		     
				//PopAndEval()	  		
      			int val2=vals->pop();
				int val1=vals->pop();
				int val3;
 				char op=syms->pop();
 
 	 		    if(op== '+'){val3 = val1+val2;}
     	    	if(op== '-'){val3 = val1-val2;}  
      	    	if(op== '*'){val3 = val1*val2;}    
           		if(op== '/'){val3 = val1/val2;}    
	       		
				vals->push(val3); //push onto values stack

		  	}
		  	
		  	//If an open parenthasie doesnt have a closed one printout an error statment
		  	if(syms->isEmpty()==1){
		  		printf("\n\nERRPR WITH PAENRAHSIS, the expression may not be correct!\n\n");
		  		return;
			  }
			  
			else			
				syms->pop(); //pop operator stack
			  	
		} 	   
            	  
 	}//end of opElseIf  

 
        // add code to perform this operation here
    inputToken = tr->getNextToken (); //do not remove~!

 }//end while
 

    /* get next token from input */
   

 /* The expression has reached its end */
 //Follow algorithm...
 	while(syms->isEmpty()!=1){
       	
		//PopAndEval()....	       		
      	int val2=vals->pop();
		int val1=vals->pop();
		int val3;
 		char op=syms->pop();
 
 	    if(op== '+'){val3 = val1+val2;}
       	if(op== '-'){val3 = val1-val2;}  
       	if(op== '*'){val3 = val1*val2;}    
      	if(op== '/'){val3 = val1/val2;}    
	       	
		vals->push(val3); //Push onto values stack

		}
 int Result=vals->pop(); //Result is top of the values stack
 
 if(vals->isEmpty()!=1){
 	printf("\nError, stack is not empty\n"); //If the stack is not empty something went wrong and the result may be wrong
	return; 
 }
 
 else
 printf("\n\nThe Result of the expression is %d", Result); //If its empty print the top of the stack (stored in Result). 

 
  printf ("\n");


}

