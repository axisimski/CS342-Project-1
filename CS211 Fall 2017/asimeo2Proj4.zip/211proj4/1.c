#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"


//This functions mallocs a new node and sticks it to the queue;
void addToList(NODE **head, int size, char*name, int status){	

	NODE *p = (NODE *) malloc(sizeof(NODE)); 
	p->size = size;
	p->name = name;
	p->status=status;
	p->next=NULL;	 

	//If the list is empty is null just set it to p. 
	if(*head == NULL){
		*head = p; 	
	}
	
	//if not stick p to the back of the list.
	else{
		NODE *tmp = *head; 
		
		while(tmp->next != NULL){
			tmp = tmp->next;
		}
			
		tmp->next = p; 		
	}
}//----------------------------------------------------------------end addtoLIST
	
//traverse the list and check for whether a name exists or not,
int doesNameExist(NODE **head, char *search, int deBug ){
	
	char *present;
	int count=0; //Not sure what this does, (I did this part of the project like two weeks ago). Should've put a coment. Anyway don't want 
	//to remove it in case it does something inmportant. 

	NODE *tmp = *head; 
		
	while(tmp != NULL){
		
		//compare each name in the list to whatever name we are searching fro.-
		if(strcmp(tmp->name, search) == 0){
			
			return TRUE;	 //found the name				
		} 
		else{
			count++;
		if(tmp->status != 0)
			present = "No";
		else
			present = "Yes";
		
		//Print debuging info
		if(deBug==1){
	 	
	 	printf("Debuging info, name: %s, size; %d, status; %s\n",tmp->name,  tmp->size, present);
	 	
	 }	
			tmp = tmp->next; //else loop trough the lsit	
		
		}
		
	}
	
	//Name isn't there
	return FALSE;	 
	
}

//Loop trough the list till it finds the right node and update the status.
void updateStatus(NODE **head, char *search, int deBug){
	
	char *present;
	int count=0;
	NODE *tmp = *head; 		
	while(tmp != NULL){
			
	if(strcmp(tmp->name, search) == 0){ //Look for the name
			
			 if(tmp->status==1){ //Update status only if the group isn't there 
			
			 	tmp->status=0; //If found update status
			 	count++;
			 }			
		} 
	
	//Print debuging info
	if(tmp->status != 0)
			present = "No";
		else
			present = "Yes";
		
		//Print debuging info
		if(deBug==1){
	 	
	 	printf("\nDebuging info, name: %s, size; %d, status; %s\n",tmp->name,  tmp->size, present);
	 	
	 }	
	 //loop trough the list
	 tmp=tmp->next;
	 
	 
 
	}
	//No such group was found or its already in the resturant.
	if(count==0){
		
		printf("And it already was so pay attention!");
	
	}

}

//Find the nearest group matching a size and remove the node.
void retrieveAndRemove(NODE**head, int number, int deBug){
	NODE *tmp = *head; 
	NODE *tmp2;
	char name;
	char *present;
	
	if(tmp->size==number){
		printf("\nSeating group %s", tmp->name);
			*head = (*head)->next;
		free(tmp);		
	}
	
	//loop trough the list and compare group sizes with with the availible table size.
	while(tmp->next != NULL){
			
		if( tmp->next->size==number){
			printf("\nSeating group %s", tmp->next->name);		 
			
				tmp2 = tmp->next;
				tmp->next = tmp2->next;				
				free(tmp2);
				return;
									
		}
		if(tmp->status != 0)
			present = "No";
		else
			present = "Yes";
		
		//Print debuging info
		if(deBug==1){
	 	
	 	printf("Debuging info, name: %s, size; %d, status; %s\n",tmp->name,  tmp->size, present);
	 	
	 }	
		
		else tmp=tmp->next;
	}
		 
	
	
}

//Loop trough the nodes and keep count. Than return said count
int countGroupsAhead(NODE **head, char* search, int deBug){
	
	int count=0; 
	char *present;
	NODE *tmp = *head; 
		
	while(tmp != NULL){
			
		if(strcmp(tmp->name, search) == 0){ //Stop looping if the target group id found
			
			return count;					
		} 
		else{
			count++; //else increase count for every itteration
			
		if(tmp->status != 0)
			present = "No";
		else
			present = "Yes";
			
	//Print debuging info		
	if(deBug==1){
	 	
	 	printf("Debuging info, name: %s, size; %d, status; %s\n",tmp->name,  tmp->size, present);
	 	
	 }	
			tmp = tmp->next; //and move to the next node			
		
		}
		
	}
	

	return;	 

}//----------------------------------------------------------------count ahead

//Same as countgroups ahead except this time we display the group names and statuses
//NOT gonna use deBug mode here since this already displays all the info.
void displayGroupSizeAhead(NODE **head, char* search, int deBug){
	
	NODE *tmp = *head;
	char *present;
	int null=0;
	int count= countGroupsAhead(head, search, deBug); //Count all the groups
	int i;
	
	//Loop from the begining to the cout varriable printing the group infos.
	for(i=0;i<count;i++){
			if(tmp->status != 0)
			present = "No";
			else
			present = "Yes";
			printf("\n|Name?: %s |How many?: %d |Present? %s|\n",  tmp->name, tmp->size, present);
			
				tmp=tmp->next;
	}	
}////----------------------------------------------------------------display ahead

//Loop trough the list and print the info in each node. No debug mode since it already prints the information. 
void displayListInformation(NODE **head){
	
	NODE *tmp = *head;
	char *present;
	int null=0;
	
	//Loop until we reach the end of the lsit. 
	while(tmp != NULL){
		null++;
		if(tmp->status != 0)
			present = "No";
		else
			present = "Yes";
		printf("|Name?: %s |How many?: %d |Present? %s|\n",  tmp->name, tmp->size, present);
		tmp = tmp->next;
	}
	
	if(null<1){
		printf("No customers\n");
	}
}//----------------------------------------------------------------end display


//########################################################################################################LINKED FNS



