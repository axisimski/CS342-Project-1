
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//c=1(Not there)

typedef enum {FALSE = 0, TRUE, NO = 0, YES} boolean;
 

typedef struct node{
	char *name;
	int size;
	int status;
	struct node *next;
} NODE;

void addToList(NODE **head, int size, char*name, int status);
int doesNameExist(NODE **head, char *search, int deBug);
void updateStatus(NODE **head, char *search, int deBug);
void retrieveAndRemove(NODE**head, int number, int deBug);
int countGroupsAhead(NODE **head, char* search, int deBug);
void displayGroupSizeAhead(NODE **head, char* search, int deBug);
void displayListInformation(NODE **head);

void clearToEoln();
int getNextNWSChar ();
int getPosInt ();
char *getName();
void printCommands();

void doAdd (NODE** head,  int deBug);
void doCallAhead (NODE **head, int deBug);
void doWaiting (NODE**head, int deBug);
void doRetrieve (NODE**head, int deBug);
void doList (NODE**head, int deBug);
void doDisplay (NODE **head );














