#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"

void doAdd (NODE** head, int deBug)
{
 /* get group size from input */
 int size = getPosInt();
 if (size < 1)
   {
    printf ("Error: Add command requires an integer value of at least 1\n");
    printf ("Add command is of form: a <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }

 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: Add command requires a name to be given\n");
    printf ("Add command is of form: a <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }
   
   if(doesNameExist (head, name, deBug)==TRUE, deBug){
   	printf("THE NAME ALREADY EXISTS!");
   }
   
   else{
   	printf ("Adding group \"%s\" of size %d\n", name, size);

  addToList(head,  size, name,  0);/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   }

 
}


void doCallAhead (NODE **head, int deBug)
{
 /* get group size from input */
 int size = getPosInt();
 if (size < 1)
   {
    printf ("Error: Call-ahead command requires an integer value of at least 1\n");
    printf ("Call-ahead command is of form: c <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }

 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: Call-ahead command requires a name to be given\n");
    printf ("Call-ahead command is of form: c <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }
   if(doesNameExist (head, name,deBug)==TRUE){
   	printf("THE NAME ALREADY EXISTS!");
   }
   
   else{
   	printf ("Call-ahead group \"%s\" of size %d\n", name, size);

  	addToList(head,  size, name,  1);/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
   	
   }
 

void doWaiting (NODE**head, int deBug)
{
 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: Waiting command requires a name to be given\n");
    printf ("Waiting command is of form: w <name>\n");
    printf ("  where: <name> is the name of the group that is now waiting\n");
    return;
   }
   
   if(doesNameExist (head, name, deBug)==FALSE){
   	printf("The name does %s does not exist!", name);
   }
else{
 printf ("Waiting group \"%s\" is now in the restaurant\n", name);

 updateStatus(head, name, deBug);	
}

}

void doRetrieve (NODE**head, int deBug)
{
 /* get table size from input */
 char* name;
 int size = getPosInt();
 if (size < 1)
   {
    printf ("Error: Retrieve command requires an integer value of at least 1\n");
    printf ("Retrieve command is of form: r <size>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    return;
   }
 clearToEoln();
 printf ("Retrieve (and remove) the first group that can fit at a tabel of size %d\n", size);

  retrieveAndRemove (head, size, deBug);
 

}

void doList (NODE**head, int deBug)
{
 /* get group name from input */
 char *name = getName();
 int count=-1;
 count=countGroupsAhead(head, name, deBug);
 if (NULL == name)
   {
    printf ("Error: List command requires a name to be given\n");
    printf ("List command is of form: l <name>\n");
    printf ("  where: <name> is the name of the group to inquire about\n");
    return;
   }

   if(doesNameExist (head, name, deBug)==FALSE){
   	printf("\nTHE NAME DOES NOT EXIST!\n");
   }
 else{
 		printf("There are %d groups ahead of %s", count, name);

 	printf ("Group \"%s\" is behind the following groups\n", name);

	displayGroupSizeAhead(head, name, deBug);
 	
 }
 


 
 }
 
void doDisplay (NODE **head)
{
 clearToEoln();
 printf ("Display information about all groups\n");

displayListInformation(head);
}

//######################################################################################################################

