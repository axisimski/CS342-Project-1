**********************HOW TO RUN THE PROGRAM***********************

-bert.cs.uic.edu //Or something similar
-make 
-java ExamTester  
-The questions will be printed along with the possible answers
-For question 1 and 2 if the answer is a, the user inputs 1, if b 2, if c 3...ENTER.
-For questions 3 and 4 you have to input a string Answer immidiattly after entering theanswer to question 2 (You don't get another prompt).

The Answers are;

pick Berlin for "What is the capital of Germany?"
pick Sofia for "What is the capital of Bulgaria?"

NOTE!!! Answers must follow proper capitalization to be recognized as correct. 'Paris' does not equal 'paris' for the purposes of the exam
type Paris for "What is the capital of France?"
type Moscow for "What is the capital of Russia?"

-The questions and answers will be shuffled printed again.
-The exam will be graded and your score will be printed.
-Questions 1 and 2 are worth 1 point each. Question 3 is worth 5 points, Question 3 is worth 10 points for a total of 17 points.

 

**********************OTHER STUFF/MORE DETAIL***********************

My project consists of multiple interconected classes so it is a bit difficult to explain what is going on internaly, but generally speaking it is alligned with Professr Bell's diagrams (avalible on the class website). Since the Exam does not provide a getQuestion method the points the tester got for each question are printed in the exam class instead of the exam tester. To the best of my knowledge everything should work as described in the project prompt.